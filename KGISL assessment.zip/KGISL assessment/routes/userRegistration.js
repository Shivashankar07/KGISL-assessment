const express = require("express");

const Router = express.Router();

const conn = require("../connection");
var moment = require("moment");

// regex validation
var letters = /^[a-zA-Z_ ]*$/;
var validRegex =
  /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
var regularExpression =
  /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/;

//   FirstName,LastName,UserName (unique), Email (unique), Phone Number
// with country code,Password

try {
  Router.post("/", (req, res) => {
    var fName = req.body["firstName"];
    var lName = req.body["lastName"];
    var uName = req.body["userName"];
    var email = req.body["email"];
    var phone = req.body["phone"];
    var password = req.body["password"];
    var createdOn = getCurrentDateTime();

    var date1 = new Date(doj);
    var doj = moment(date1).format("YYYY-MM-DD");

    // validation part
    if (req.body) {
      if (!fName || !fName.match(letters)) {
        res.send({
          status: 422,
          message: "",
          errorMsg: "Please enter a valid first name",
        });
      } else if (!lName || !lName.match(letters)) {
        res.send({
          status: 422,
          message: "",
          errorMsg: "Please enter a valid last name",
        });
      } else if (!uName) {
        res.send({
          status: 422,
          message: "",
          errorMsg: "Please enter a valid user name",
        });
      } else if (!email || !email.match(validRegex)) {
        res.send({
          status: 422,
          message: "",
          errorMsg: "Please enter a valid email address",
        });
      } else if (!phone) {
        res.send({
          status: 422,
          message: "",
          errorMsg: "Please enter a phone number",
        });
      } else if (!password) {
        res.send({
          status: 422,
          message: "",
          errorMsg: "Please enter a valid password",
        });
      } else if (!password.match(regularExpression)) {
        res.send({
          status: 422,
          message: "",
          errorMsg:
            "Password should contain atleast one number, one special character and must be between 6 and 16 characters",
        });
      } else {
        var selQry =
          "SELECT id from emp_registration where uname='" +
          uName +
          "' or email='" +
          email +
          "'";
        conn.query(selQry, (err, rows, fields) => {
          if (err) {
            res.send({
              status: 422,
              message: "",
              errorMsg: "Something went wrong",
            });
          } else {
            if (rows.length > 0) {
              res.send({
                status: 422,
                message: rows.length,
                errorMsg:
                  "Already the username or email exist, please try with different data",
              });
            } else {
              var qry =
                "INSERT INTO emp_registration (`id`, `fname`, `lname`,`uname`, `email`, `password`, `phone_cc`, `created_on`) VALUES ('','" +
                fName +
                "','" +
                lName +
                "','" +
                uName +
                "','" +
                email +
                "','" +
                password +
                "','" +
                phone +
                "','" +
                createdOn +
                "')";
              conn.query(qry, (err, rows, fields) => {
                if (err) {
                  console.log(err);
                  res.send({
                    status: 500,
                    message: "",
                    errorMsg: "Cannot insert the record, please try again",
                  });
                } else {
                  res.status(201).send({
                    message: "User registration completed successfully",
                    errorMsg: "",
                  });

                  var actCheck =
                    "SELECT id from activation_link_config WHERE email_send =1";
                  conn.query(actCheck, (err, rows, fields) => {
                    if (err) {
                      console.log(err);
                    } else {
                      if (rows.length > 0) {
                        sendMail(email, fName, uName, password);
                      }
                    }
                  });
                }
              });
            }
          }
        });
      }

      // check username or email exist
    } else {
      res.send({
        status: 422,
        message: "",
        errorMsg: "Please provide a valid request",
      });
    }
  });

  function getCurrentDateTime() {
    var today = new Date();
    var date =
      today.getFullYear() +
      "-" +
      (today.getMonth() + 1) +
      "-" +
      today.getDate();
    var time =
      today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var dateTime = date + " " + time;
    return dateTime;
  }

  function sendMail(empEmail, empName, uName, password) {
    var nodemailer = require("nodemailer");

    var transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: "username@gmail.com",
        pass: "password",
      },
    });

    var mailOptions = {
      from: "username@gmail.com",
      to: empEmail,
      subject: "Activate your employee account",
      html:
        "<h1>Welcome " +
        empName +
        ",</h1><p>New employee account created</p><p>Email - " +
        empEmail +
        "</p><p>Password - " +
        password +
        "</p>" +
        ' <br/><a href="http://google.com?uname="' +
        uName +
        '"&pwd="' +
        password +
        '" style="background-color: #4CAF50;border: none; color: white; padding: 15px 32px;text-align: center;text-decoration: none;display: inline-block;font-size: 16px;margin: 4px 2px;cursor: pointer;" class="button">Activation link</a>' +
        "<br/>Thanks!",
    };

    transporter.sendMail(mailOptions, function (error, info) {
      if (error) {
        console.log(error);
      } else {
        console.log("Email sent: " + info.response);
      }
    });
  }
} catch (err) {
  res.send({
    status: 500,
    message: "",
    errorMsg: "Something went wrong, please try after some time ",
  });
}

module.exports = Router;
