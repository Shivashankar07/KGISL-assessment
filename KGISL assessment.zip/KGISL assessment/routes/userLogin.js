const express = require("express");
const Router = express.Router();
const conn = require("../connection");
const jwt = require("jsonwebtoken");

var validRegex =
  /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

try {
  Router.post("/", (req, res) => {
    if (req.body) {
      var uName = req.body.userName;
      var empEmail = req.body.email;
      var pwd = req.body.password;

      if (empEmail) {
        if (!empEmail.match(validRegex)) {
          res.send({
            status: 422,
            message: "",
            errorMsg: "Please enter a valid email address",
          });
        }
      }

      if (!uName && !empEmail) {
        res.send({
          status: 422,
          message: "",
          errorMsg: "Please enter a valid email address or username",
        });
      } else if (!pwd) {
        res.send({
          status: 422,
          message: "",
          errorMsg: "Please enter a valid password",
        });
      } else {
        var qry = "";
        var userInfo = {};
        if (uName) {
          qry =
            "SELECT id from emp_registration where uname='" +
            uName +
            "' AND password='" +
            pwd +
            "'";
          userInfo = {
            username: uName,
            password: pwd,
          };
        } else if (empEmail) {
          qry =
            "SELECT id from emp_registration where email='" +
            empEmail +
            "' AND password='" +
            pwd +
            "'";
          userInfo = {
            email: empEmail,
            password: pwd,
          };
        }

        conn.query(qry, (err, rows, fields) => {
          if (err) {
            throw err;
          } else {
            if (rows.length > 0) {
              //   signing with token
              const token = jwt.sign({ user: userInfo }, "secretkey");
              const rfToken = jwt.sign(userInfo, "secretkey");

              res.send({
                status: 200,
                message: "Employee logged in successfully",
                accessToken: token,
                refreshToken: rfToken,
                errorMsg: "",
              });
            } else {
              res.send({
                status: 500,
                message: "",
                errorMsg: "User account does not exist, please register ",
              });
            }
          }
        });
      }
    } else {
      res.send({
        status: 500,
        message: "",
        errorMsg: "Please provide a valid request ",
        employeeList: rows,
      });
    }
  });
} catch (err) {
  res.send({
    status: 500,
    message: "",
    errorMsg: "Something went wrong, please try after some time ",
  });
}

module.exports = Router;
