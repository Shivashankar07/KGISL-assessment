const express = require("express");

const Router = express.Router();
const upload = require("express-fileupload");

const conn = require("../connection");
var moment = require("moment");

// app.use(upload());

// regex validation
var letters = /^[a-zA-Z_ ]*$/;
var validRegex =
  /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
var regularExpression =
  /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/;

//   FirstName,LastName,UserName (unique), Email (unique), Phone Number
// with country code,Password

Router.use(express.json());
try {
  Router.post("/", (req, res) => {
    var fName = req.body["firstName"];
    var lName = req.body["lastName"];
    var email = req.body["email"];
    var phone = req.body["phone"];
    var caddress = req.body["c_address"];
    var naddress = req.body["n_address"];

    var createdOn = getCurrentDateTime();

    var date1 = new Date(doj);

    var doj = moment(date1).format("YYYY-MM-DD");
    var profpic = "";
    var resume = "";
    var ts = Math.floor(Date.now() / 1000);

    // validation part
    if (req.body) {
      if (!fName || !fName.match(letters)) {
        res.send({
          status: 422,
          message: "",
          errorMsg: "Please enter a valid first name",
        });
      } else if (!lName || !lName.match(letters)) {
        res.send({
          status: 422,
          message: "",
          errorMsg: "Please enter a valid last name",
        });
      } else if (!email || !email.match(validRegex)) {
        res.send({
          status: 422,
          message: "",
          errorMsg: "Please enter a valid email address",
        });
      } else if (!phone) {
        res.send({
          status: 422,
          message: "",
          errorMsg: "Please enter a phone number",
        });
      } else if (!caddress) {
        res.send({
          status: 422,
          message: "",
          errorMsg: "Please enter a valid current address",
        });
      } else if (!naddress) {
        res.send({
          status: 422,
          message: "",
          errorMsg: "Please enter a valid native address",
        });
      } else {
        var errCount = 0;

        if (req.files) {
          // console.log("files received", req.files);
          var ppfile = req.files.profile_picture;
          if (ppfile) {
            profpic = ts + ppfile.name;

            var allowedExtensions = /(\.jpg|\.jpeg|\.png|\.gif)$/i;
            var resumeExtensions = /(\.pdf|\.doc|\.docx|\.docm)$/i;

            if (!allowedExtensions.exec(profpic)) {
              errCount += 1;
              res.send({
                status: 422,
                message: "",
                errorMsg:
                  "Please upload profile picture having extensions .jpeg/.jpg/.png/.gif only.",
              });
            } else {
              ppfile.mv(
                "./uploads/profile_picture/" + profpic,
                function (err, data) {
                  if (err) {
                    console.log("profile picture upload errr", err);
                  } else {
                    console.log("profile picture uploaded", data);
                  }
                }
              );
            }
          }

          var resFile = req.files.resume;
          if (resFile) {
            resume = ts + resFile.name;
            if (!resumeExtensions.exec(resume)) {
              errCount += 1;
              res.send({
                status: 422,
                message: "",
                errorMsg:
                  "Please upload resume having extensions .jpeg/.jpg/.png/.gif only.",
              });
            } else {
              resFile.mv("./uploads/resume/" + resume, function (err, data) {
                if (err) {
                  console.log(" resume upload errr", err);
                } else {
                  console.log("resume uploaded", data);
                }
              });
            }
          }
        }

        console.log("err", errCount);

        if (errCount == 0) {
          var selQry =
            "SELECT id from user_profile where email='" + email + "'";
          conn.query(selQry, (err, rows, fields) => {
            if (err) {
              res.send({
                status: 422,
                message: "",
                errorMsg: "Something went wrong",
              });
            } else {
              if (rows.length > 0) {
                res.send({
                  status: 422,
                  message: "",
                  errorMsg:
                    "Entered email already exist, please try with different data",
                });
              } else {
                var qry =
                  "INSERT INTO `user_profile` (`id`, `fname`, `lname`, `email`, `profile_pic`, `phone_cc`, `c_address`, `n_address`, `resume`, `created_on`, `updated_on`) VALUES  ('','" +
                  fName +
                  "','" +
                  lName +
                  "','" +
                  email +
                  "','" +
                  profpic +
                  "','" +
                  phone +
                  "','" +
                  caddress +
                  "','" +
                  naddress +
                  "','" +
                  resume +
                  "','" +
                  createdOn +
                  "','')";
                conn.query(qry, (err, rows, fields) => {
                  if (err) {
                    console.log(err);
                    res.send({
                      status: 500,
                      message: "",
                      errorMsg: "Cannot insert the record, please try again",
                    });
                  } else {
                    var lastInsertId = rows.insertId;

                    if (req.body.educationDetails) {
                      var eduDetail = req.body.educationDetails;
                      console.log("edu", eduDetail[0]);
                      for (var i in eduDetail) {
                        var passOut = eduDetail[i].pass_out;
                        var institution = eduDetail[i].institution;
                        var degree = eduDetail[i].degree;
                        var percent = eduDetail[i].percent;

                        if (!passOut) {
                          res.send({
                            status: 422,
                            message: "",
                            errorMsg: "Please enter pass out ",
                          });
                        } else if (!institution) {
                          res.send({
                            status: 422,
                            message: "",
                            errorMsg: "Please enter institution ",
                          });
                        } else if (!degree) {
                          res.send({
                            status: 422,
                            message: "",
                            errorMsg: "Please enter degree ",
                          });
                        } else if (!percent) {
                          res.send({
                            status: 422,
                            message: "",
                            errorMsg: "Please enter percent ",
                          });
                        } else {
                          var qry =
                            "INSERT INTO education_details (`id`, `user_id`, `passed_year`, `institution`, `degree`, `percent`) VALUES (''," +
                            lastInsertId +
                            "," +
                            parseInt(passOut) +
                            ",'" +
                            institution +
                            "','" +
                            degree +
                            "'," +
                            parseInt(percent) +
                            ")";

                          conn.query(qry, (err, rows, fields) => {
                            if (err) {
                              console.log(err);
                            } else {
                              console.log("education details inserted");
                            }
                          });
                        }
                      }
                    }

                    if (req.body.workDetails) {
                      var workDetail = req.body.workDetails;
                      console.log("wrk", workDetail[0]);
                      for (var i in workDetail) {
                        var company = workDetail[i].company;
                        var start_date = workDetail[i].start_date;
                        var end_date = workDetail[i].end_date;

                        if (!company) {
                          res.send({
                            status: 422,
                            message: "",
                            errorMsg: "Please enter company ",
                          });
                        } else if (!start_date) {
                          res.send({
                            status: 422,
                            message: "",
                            errorMsg: "Please enter start date ",
                          });
                        } else if (!end_date) {
                          res.send({
                            status: 422,
                            message: "",
                            errorMsg: "Please enter end_date ",
                          });
                        } else {
                          var qry =
                            "INSERT INTO work_details (`id`, `user_id`, `company`, `start_date`, `end_date`) VALUES (''," +
                            lastInsertId +
                            ",'" +
                            company +
                            "','" +
                            start_date +
                            "','" +
                            end_date +
                            "')";

                          conn.query(qry, (err, rows, fields) => {
                            if (err) {
                              console.log(err);
                            } else {
                              console.log("work details inserted");
                            }
                          });
                        }
                      }
                    }

                    res.status(201).send({
                      message: "User profile created successfully",
                      errorMsg: "",
                    });
                  }
                });
              }
            }
          });
        }
      }

      // check username or email exist
    } else {
      res.send({
        status: 422,
        message: "",
        errorMsg: "Please provide a valid request",
      });
    }
  });

  function getCurrentDateTime() {
    var today = new Date();
    var date =
      today.getFullYear() +
      "-" +
      (today.getMonth() + 1) +
      "-" +
      today.getDate();
    var time =
      today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var dateTime = date + " " + time;
    return dateTime;
  }
} catch (err) {
  res.send({
    status: 500,
    message: "",
    errorMsg: "Something went wrong, please try after some time ",
  });
}

module.exports = Router;
