const express = require("express");

const Router = express.Router();

const conn = require("../connection");

// var async = require("async");

try {
  Router.get("/", (req, res) => {
    var userId = req.query.id;
    if (!userId) {
      res.send({
        status: 422,
        message: "",
        errorMsg: "Please enter a valid user ID ",
      });
    } else {
      var profileList = [];
      var eduData = [];
      var workData = [];

      conn.query(
        "SELECT * FROM user_profile where id='" + userId + "'",
        async function (err, rows, fields) {
          if (err) {
            console.log(err);
          } else {
            profileList = rows;
            for (var i in profileList) {
              userId = profileList[i].userId;

              eduData = await getEduDetails(profileList[i].id);
              workData = await getWorkDetails(profileList[i].id);
              profileList[i]["educationDetails"] = eduData;
              profileList[i]["workDetails"] = workData;
            }
            res.status(200).send({
              message: "User profiles retrieved successfully",
              empData: profileList,
              errorMsg: "",
            });
          }
        }
      );
    }
  });

  function getEduDetails(userId) {
    return new Promise(function (resolve, reject) {
      conn.query(
        "SELECT institution,passed_year,degree,percent FROM education_details where user_id='" +
          userId +
          "' ",
        function (err, result) {
          if (err) {
            reject(err);
          } else {
            resolve(result);
          }
        }
      );
    });
  }

  function getWorkDetails(userId) {
    return new Promise(function (resolve, reject) {
      conn.query(
        "SELECT company,start_date,end_date FROM work_details where user_id='" +
          userId +
          "' ",
        function (err, result) {
          if (err) {
            reject(err);
          } else {
            resolve(result);
          }
        }
      );
    });
  }
} catch (err) {
  console.log("err", err);
}
module.exports = Router;
