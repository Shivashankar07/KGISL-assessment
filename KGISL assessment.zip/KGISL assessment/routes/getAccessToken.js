const express = require("express");
const Router = express.Router();
const jwt = require("jsonwebtoken");

const { verifyRefresh } = require("./helper");

try {
  Router.post("/", (req, res) => {
    if (req.body.refreshToken && req.body.email) {
      const { email, refreshToken } = req.body;
      const isValid = verifyRefresh(email, refreshToken);

      if (!isValid) {
        res
          .status(401)
          .json({ success: false, error: "Invalid token,try login again" });
      }
      const accessToken = jwt.sign({ email: email }, "secretkey");
      // return res.status(200).json({ success: true, accessToken });

      res.send({
        status: 200,
        message: "Access token retrieved successfully",
        accessToken: accessToken,
        errorMsg: "",
      });
    } else if (req.body.email) {
      res.send({
        status: 422,
        message: "",
        errorMsg: "Please provide a valid email",
      });
    } else if (req.body.refreshToken) {
      res.send({
        status: 422,
        message: "",
        errorMsg: "Please provide a valid refresh token",
      });
    }
  });
} catch (err) {
  res.send({
    status: 500,
    message: "",
    errorMsg: "Something went wrong, please try after some time ",
  });
}

module.exports = Router;
