const express = require("express");

const Router = express.Router();

const conn = require("../connection");

try {
  Router.post("/", (req, res) => {
    var userId = req.body["userId"];

    if (!userId) {
      res.send({
        status: 422,
        message: "",
        errorMsg: "Please enter a valid userId",
      });
    } else {
      conn.query(
        "DELETE FROM user_profile WHERE id='" + userId + "' ",
        (err, rows, fields) => {
          if (err) {
            console.log(err);
          } else {
            if (rows.affectedRows > 0) {
              conn.query(
                "DELETE FROM work_details WHERE user_id='" + userId + "' ",
                (err, rows, fields) => {}
              );
              conn.query(
                "DELETE FROM education_details WHERE user_id='" + userId + "' ",
                (err, rows, fields) => {}
              );
              res.status(200).send({
                status: 200,
                message: "user profile deleted successfully",
                errorMsg: "",
              });
            } else {
              res.send({
                status: 500,
                message: "",
                errorMsg: "Please enter a valid employee ID ",
              });
            }
          }
        }
      );
    }
  });
} catch (err) {
  res.send({
    status: 500,
    message: "",
    errorMsg: "Something went wrong, please try after some time ",
  });
}

module.exports = Router;
