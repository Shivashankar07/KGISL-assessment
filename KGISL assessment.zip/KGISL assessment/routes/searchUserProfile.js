const express = require("express");

const Router = express.Router();

const conn = require("../connection");

try {
  Router.post("/", (req, res) => {
    var searchtext = req.body.searchText;
    if (!searchtext) {
      res.send({
        status: 422,
        message: "",
        errorMsg: "Please enter a valid searchtext",
      });
    } else {
      var count = 0;
      conn.query(
        "SELECT count(id) as count from user_profile",
        (err, rows, fields) => {
          if (!err) {
            count = rows[0].count;
          }
        }
      );
      conn.query(
        "SELECT * from user_profile a  WHERE fname like '%" +
          searchtext +
          "%' or lname like '%" +
          searchtext +
          "%' or email like '%" +
          searchtext +
          "%' or phone_cc like '%" +
          searchtext +
          "%' or c_address like '%" +
          searchtext +
          "%' or n_address like '%" +
          searchtext +
          "%'",
        (err, rows, fields) => {
          if (err) {
            console.log(err);
          } else {
            res.status(200).send({
              message: "User profiles retrieved successfully",
              empData: rows,
              totalCount: count,
              filteredCount: rows.length,
              errorMsg: "",
            });
          }
        }
      );
    }
  });
} catch (err) {
  res.send({
    status: 500,
    message: "",
    errorMsg: "Something went wrong, please try after some time ",
  });
}

module.exports = Router;
