const mysql = require("mysql");

var conn = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "employee_kgisl",
  multipleStatements: true,
});

conn.connect((err) => {
  if (err) {
    throw err;
  } else {
    console.log("Connected");
  }
});

module.exports = conn;
