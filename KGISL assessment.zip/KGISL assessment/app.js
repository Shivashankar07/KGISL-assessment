const express = require("express");
const app = express();
const upload = require("express-fileupload");
const conn = require("./connection");
var moment = require("moment");
var bodyParser = require("body-parser");

app.use(express.json());
app.use(bodyParser.json());

app.use(express.urlencoded({ extended: false }));
app.use(upload());

// regex validation
var letters = /^[a-zA-Z_ ]*$/;
var validRegex =
  /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

//  1. Registration form data
try {
  app.use("/userregistration", require("./routes/userRegistration"));
} catch (err) {
  console.log("err");
}

//  2. User login with access and refresh token
try {
  app.use("/userLogin", require("./routes/userLogin"));
} catch (err) {
  console.log("err");
}

//  3. get accesstoken using refresh token
try {
  app.use("/getAccessToken", require("./routes/getAccessToken"));
} catch (err) {
  console.log("Err", err);
}

//  4. create user profile
try {
  app.use("/createUserProfile", require("./routes/createUserProfile"));
} catch (err) {
  console.log("Err", err);
}

//  5. update user profile
try {
  app.use("/updateUserProfile", require("./routes/updateUserProfile"));
} catch (err) {
  console.log("Err", err);
}

//  6. list user profile
try {
  app.use("/listUserProfile", require("./routes/listUserProfile"));
} catch (err) {
  console.log("Err", err);
}

//  7. delete user profile
try {
  app.use("/deleteUserProfile", require("./routes/deleteUserProfile"));
} catch (err) {
  console.log("Err", err);
}

//  8. get user profile
try {
  app.use("/getUserProfile", require("./routes/getUserProfile"));
} catch (err) {
  console.log("Err", err);
}

//  9. search user profile
try {
  app.use("/searchUserProfile", require("./routes/searchUserProfile"));
} catch (err) {
  console.log("Err", err);
}

app.listen("3000", (req, res) => {
  console.log("app started");
});
